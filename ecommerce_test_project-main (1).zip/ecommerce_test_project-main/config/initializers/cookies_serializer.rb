# frozen_string_literal: true

Rails.application.config.action_dispatch.cookies_serializer = :json
